# KTU B.Tech S7 Seminar Report Skill for Antigravity

This skill enables Antigravity to automatically create, format, and compile official KTU S7 B.Tech Seminar Reports (Amal Jyothi College of Engineering standard) with zero manual LaTeX configuration.

## How to Install & Use:

### Option 1: Global Skill (Recommended)
Copy the ktu-seminar-report folder into:
- Windows: C:\Users\<YourUsername>\.gemini\config\skills\ktu-seminar-report
- Mac/Linux: ~/.gemini/config/skills/ktu-seminar-report

### Option 2: Project-Specific Skill
Copy the ktu-seminar-report folder into your project folder under:
- <project-root>/.agents/skills/ktu-seminar-report

## How it works:
1. When asked to create a seminar report, the AI prompts you for your topic, student name, register number, and faculty guide.
2. It generates all necessary LaTeX files with exact margins, spacing, and signatures.
3. It automatically downloads the standalone Tectonic LaTeX engine if you don\'t have LaTeX installed, and compiles your report to a ready-to-print PDF!
