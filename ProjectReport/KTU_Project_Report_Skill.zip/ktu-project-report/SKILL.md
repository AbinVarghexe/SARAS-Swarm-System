---
name: ktu-project-report
description: >-
  Create, format, and compile official KTU B.Tech Computer Science Project Reports
  (Phase I & Final Report, Amal Jyothi College of Engineering standard).
  Enforces exact LaTeX formatting, single-page Cover & Certificate alignments,
  Chapter structuring (Chapters 1 to 5), table/figure styling, and automated zero-dependency
  compilation with Tectonic. Guides users by first prompting for content.md and assets/ folder.
---

# KTU B.Tech Computer Science Project Report Skill

This skill guides the AI assistant in creating, formatting, customizing, and compiling official B.Tech Project Reports (Phase I and Final Phase) adhering strictly to the guidelines of the **Department of Computer Science and Engineering, Amal Jyothi College of Engineering (Autonomous), APJ Abdul Kalam Technological University (KTU)**.

---

## 1. Mandatory Input Gathering (First Action)

When this skill is activated or when a user requests a project report, **ALWAYS perform these two steps first**:

### Step 1.1: Interactive Asset & Content Collection (Mandatory First Action)
Before writing or modifying any LaTeX files, **proactively prompt the user** to gather input:

1. **Project Markdown / Notes (`content.md`):**
   Ask: *"Please share your `content.md` file or paste your project details (objectives, literature papers, implementation modules, and results)."*

2. **Interactive Image & Diagram Checklist:**
   Explicitly prompt the user:
   > *"Please provide the images for your report by placing them into the `assets/` folder (or upload them here). Do you have images for:*
   > - *1. Conceptual Overview or Domain Diagram (Figure 1.1)*
   > - *2. System Architecture / Block Diagram / Hardware Setup (Figure 3.1)*
   > - *3. Methodology Flowchart or Algorithm Pipeline (Figure 3.2)*
   > - *4. Results Benchmarks / Accuracy / Loss / Latency Graphs (Figure 4.1)*
   > - *5. Output Visualizations / Dashboard Screenshots / Demo Captures (Figure 4.2)*
   >
   > *If images are already in your project folders (e.g., presentations, docs, test folders), let me know and I will automatically extract and collect them for you."*

3. **Fallback Handling for Images:**
   - If the user provides images, place them in `assets/` with clean names (e.g., `architecture.png`, `results_graph.png`) and reference them with proper `\caption{...}` and `\label{...}`.
   - If the user does not have images ready, use graceful placeholder figures or offer to generate clean Mermaid/TikZ diagrams or extract figures from existing project files.

### Step 1.2: Confirm Project & Department Metadata
Verify or solicit the following details:
- **Project Title:** (e.g., *SARAS: Search And Rescue Autonomous Swarm*)
- **Report Category:** *A PROJECT PHASE I REPORT* or *A PROJECT FINAL REPORT*
- **Student Details:** Full Name and KTU Register Number (e.g., `ABIN VARGHESE (AJC23CS008)`). For groups, list all members.
- **Internal Guide:** Full Name (Dr. / Prof. / Mr. / Ms.) and Academic Designation (*Assistant Professor / Associate Professor / Professor*).
- **Project Coordinator(s):** Full Name(s) and Designation.
- **Head of Department (CSE):** Dr. Juby Mathew.
- **Month & Year:** e.g., *October 2026*.
- **College Officials for Acknowledgement:**
  - Manager: Rev. Fr. Boby Alex Mannamplackal
  - Director (Administrator): Fr. Dr. Roy Abraham Pazhayaparampil
  - Principal: Dr. Lillykutty Jacob

---

## 2. Formatting & Typography Rules

All generated LaTeX files must strictly adhere to the following standard:

- **Document Class & Paper Size:** `\documentclass[a4paper,12pt]{report}`
- **Page Margins:**
  ```latex
  \usepackage[top=3cm,bottom=2.5cm,left=3cm,right=2.5cm]{geometry}
  ```
- **Line Spacing:** Double spacing for front-matter and body (`\doublespacing`), with `\begin{spacing}{1.5}` inside unnumbered front-matter chapters.
- **Headings & Fonts:**
  - Chapter titles: `\usepackage{sectsty}`, `\chapterfont{\Large\centering\MakeUppercase}`.
  - Sections: Numbered hierarchically (`1.1`, `1.2`, `1.2.1`).
- **Running Headers & Footers (`fancyhdr`):**
  ```latex
  \lhead{}
  \lfoot{\textit{Department of Computer Science and Engineering,AJCE}}
  \cfoot{}
  \rfoot{\textit{\thepage}}
  \rhead{\nouppercase{\textit{\leftmark\ }}}
  \renewcommand{\footrulewidth}{0.4pt}
  ```
- **Page Numbering Sequence:**
  - Title Page: No page number (`\thispagestyle{empty}`).
  - Front Matter (Declaration, Certificate, Acknowledgement, Abstract, TOC, LOT, LOF, Abbreviations): Lowercase Roman numerals (`\pagenumbering{roman}`).
  - Body Matter (Chapter 1 to References): Arabic numerals (`\pagenumbering{arabic}`) starting at page 1.

---

## 3. Strict Structural and Single-Page Layout Constraints

### 3.1 Title Page (`title.tex`) — MUST Fit on Exactly 1 Page
- **Typography & Highlighting:**
  - Topic Title: `{\Large\textbf{...}}`
  - Student Name: Highlighted in large bold `{\large\textbf{NAME}}` and registration number in bold `\textbf{AJC...}`
  - Faculty Guide Block: Formatted with clean line spacing between the caption, the highlighted name, and the designation:
    ```latex
    Under the guidance of\\[0.3cm]
    {\large\textbf{Dr./Prof./Mr./Ms. NAME}}\\[0.25cm]
    Assistant Professor/Associate Professor/Professor\\
    ```
  - Department: `{\large\textbf{Department of Computer Science and Engineering}}`
  - Month & Year: `{\large Month Year}`
- **Vertical Spacing Proportions (Crucial):**
  - Do NOT use `\begin{figure}` which introduces extra float margin penalties. Place the logo inside `\begin{center}\includegraphics[scale=0.2]{assets/ajcelogo2023.png}\end{center}`.
  - Distribute vertical skips evenly (`\vspace{0.8cm}` between major sections, `\vspace{0.5cm}` after the logo) so that the college name and date sit comfortably near the bottom margin ($y \approx 745\text{--}760\text{ pt}$) matching the official reference layout.

### 3.2 Certificate Page (`certificate.tex`) — MUST Fit on Exactly 1 Page
- Contains department heading, AJCE logo (`width=0.30\textwidth`), `\Large\textbf{CERTIFICATE}`, and bonafide certification paragraph.
- **Signature Block Alignment (Crucial):** Never use manual line-breaking `\hspace` values across lines, as that causes jagged horizontal offsets. Structure the two-tier supervisor and coordinator block using a full-width `tabular*` with centered column heads:
  ```latex
  \vspace{1.5cm}

  \noindent
  \begin{tabular*}{\textwidth}{@{\hspace{10pt}}c@{\extracolsep{\fill}}c@{\hspace{10pt}}}
  Dr. Jacob John & Dr. Jacob John \\
  Internal Supervisor & Project Coordinator
  \end{tabular*}

  \vspace{1.2cm}

  \begin{center}
  Dr. Juby Mathew \\
  \vspace{1pt}
  Head of Department ,CSE
  \end{center}
  ```
  This guarantees that:
  1. The Internal Supervisor title is centered directly underneath the Guide's name on the left.
  2. The Project Coordinator title is centered directly underneath the Coordinator's name on the right.
  3. The Head of Department block is centered across the bottom of the page.

### 3.3 Tables & Float Width Protection
- To prevent LaTeX `Overfull \hbox` warnings on wide tables, **always** wrap tabular environments in `\resizebox`:
  ```latex
  \begin{table}[h]
  \caption{Table Caption Here}
  \label{tab:sample}
  \begin{center}
  \resizebox{0.95\columnwidth}{!}{
  \begin{tabular}{|l|c|c|c|}
  ...
  \end{tabular}
  }
  \end{center}
  \end{table}
  ```

### 3.4 Strict Zero-Orphan & Line Distribution Rule
Never allow a chapter (such as Chapter 5 Future Work or Chapter 2 Literature Survey) to end with an isolated 1-to-3 line spillover onto a new page.
- Always inspect the generated PDF using PyMuPDF (`fitz`) or line-count verification.
- If a chapter's concluding section (e.g., Future Work bullet points or summary paragraph) has only 1–3 lines spilling onto an otherwise blank page:
  - Tighten preceding paragraphs or float spacing (`\vspace{-0.2cm}`) to pull the orphan lines onto the previous page, OR
  - Expand the section substantively with deep technical discussion or architectural diagrams so that the final page is well-balanced and filled.
- No page in the final report should ever consist of just 1 or 2 stranded sentences.

---

## 4. Standard 6-Chapter Organization

Every project report adheres strictly to this six-chapter syllabus structure:

```text
├── main.tex              # Master driver file
├── title.tex             # Cover & Title Page (Page 1)
├── declaration.tex       # Student Declaration (Page 2)
├── certificate.tex       # Department Certificate (Page 3)
├── ackn.tex              # Acknowledgement (Page 4)
├── abstract.tex          # Abstract (Page 5, 250-300 words, zero citations, no unexpanded acronyms)
├── Abbrevations.tex      # Table of Abbreviations
├── intro.tex             # Chapter 1: Introduction
│                         # 1.1 Background, 1.2 Motivation, 1.3 Problem Statement, 1.4 Objectives (1-5),
│                         # 1.5 Scope & Limitations, 1.6 Contributions, 1.7 Report Organization
├── litsurvey.tex         # Chapter 2: Literature Survey
│                         # 2.1 Domain Overview, 2.2 Classical ML, 2.3 Deep Learning, 2.4 Recent/Hybrid,
│                         # 2.5 Prior Datasets, 2.6 Comparison Table, 2.7 Research Gap (leads to Ch 3)
├── methodology.tex       # Chapter 3: Proposed Methodology
│                         # 3.1 System Overview (pipeline diagram), 3.2 Dataset Description,
│                         # 3.3 Data Preprocessing & Augmentation, 3.4 Feature Extraction & Representation,
│                         # 3.5 Model Architecture, 3.6 Loss Functions & Optimization,
│                         # 3.7 Training Strategy, 3.8 Evaluation Metrics
├── implementation.tex    # Chapter 4: Implementation
│                         # 4.1 Hardware & Software Specs, 4.2 Tools & Frameworks Table,
│                         # 4.3 Dataset Partitioning, 4.4 Hyperparameter Settings Table,
│                         # 4.5 Training Procedure & Flow, 4.6 Deployment & Ground Dashboard
├── results.tex           # Chapter 5: Results and Discussion
│                         # 5.1 Experimental Setup, 5.2 Training & Convergence Curves,
│                         # 5.3 Test Set Performance Metrics Table, 5.4 Confusion Matrix & ROC Curves,
│                         # 5.5 Baseline Model Comparison, 5.6 Existing Literature Benchmarks Table,
│                         # 5.7 Ablation Study, 5.8 Error Analysis, 5.9 Discussion & Trade-Offs
├── conclusion.tex        # Chapter 6: Conclusion and Future Work
│                         # 6.1 Conclusion (mapping to 1.4 objectives), 6.2 Limitations,
│                         # 6.3 Future Work (3-4 concrete technical extensions)
├── bibilo.tex            # References (20-30 citations, IEEE format, all cited in text)
├── Appendix.tex          # Appendix A (Key Code Snippets) & Appendix B (Visual Demonstrations)
├── content.md            # Interactive Markdown content specification
└── assets/               # High-res diagrams, architecture flowcharts, and ajcelogo2023.png
```

---

## 5. Automated Compilation Pipeline

Reports are compiled using the standalone, zero-dependency **Tectonic** engine:

```powershell
# Windows
python compile_report.py main.tex
# or using tectonic directly:
& "<path-to-bin>\tectonic.exe" main.tex --outdir .
```

`compile_report.py` automatically detects if a LaTeX compiler is present. If none is found, it automatically downloads and installs standalone Tectonic for Windows, macOS (Intel/Apple Silicon), or Linux on the fly.
